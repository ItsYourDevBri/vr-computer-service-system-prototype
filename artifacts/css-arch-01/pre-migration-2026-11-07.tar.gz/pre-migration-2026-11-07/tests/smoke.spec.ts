import { expect, test } from '@playwright/test'
import { mkdirSync } from 'node:fs'

const viewportWidths = [320, 375, 390, 430, 768, 1024, 1440]
const responsiveViewports = [[320, 568], [375, 667], [390, 844], [430, 932], [667, 375], [844, 390], [874, 402], [932, 430], [768, 1024], [1440, 900]] as const
const applicationTitle = 'VR-Based Computer Systems Servicing (CSS) Training Application'

async function signInAs(page: import('@playwright/test').Page, role: 'Student' | 'Instructor' | 'Principal') {
  await page.goto('/login')
  await page.getByLabel('Email Address').fill('preview@movers.test')
  await page.getByLabel('Password', { exact: true }).fill('demo-password')
  await page.getByRole('radio', { name: role, exact: true }).check()
  await page.getByRole('button', { name: 'Continue' }).click()
  await expect(page.getByRole('heading', { name: 'Set up your profile' })).toBeVisible()
  await page.getByRole('button', { name: 'Skip for now' }).click()
  const dashboardPath = { Student: '/student/dashboard', Instructor: '/instructor/dashboard', Principal: '/principal/dashboard' }[role]
  await expect(page).toHaveURL(new RegExp(dashboardPath.replaceAll('/', '\\/') + '$'))
}

test('landing page navigation opens centered login and invitation sign up', async ({ page }) => {
  await page.goto('/')
  await expect(page.getByRole('heading', { name: applicationTitle })).toBeVisible()
  await expect(page.getByRole('img', { name: 'Movers Institute of Technology and Education seal' })).toBeVisible()
  await expect(page.getByText('Movers Institute of Technology and Education').first()).toBeVisible()
  await expect(page.locator('.brand-name')).toHaveCount(0)
  await expect(page.getByRole('link', { name: 'Home', exact: true })).toHaveAttribute('aria-current', 'location')
  await page.getByRole('link', { name: 'About', exact: true }).click()
  await expect(page).toHaveURL(/#about$/)
  await expect(page.getByRole('link', { name: 'About', exact: true })).toHaveAttribute('aria-current', 'location')
  await expect(page.getByRole('heading', { name: 'About the CSS Training Application' })).toBeVisible()
  await expect(page.getByText('This application supplements classroom instruction and physical hands-on training.')).toBeVisible()
  await page.getByRole('link', { name: 'Features', exact: true }).click()
  await expect(page).toHaveURL(/#features$/)
  await expect(page.getByRole('link', { name: 'Features', exact: true })).toHaveAttribute('aria-current', 'location')
  await expect(page.getByRole('heading', { name: 'Explore the Learning Experience' })).toBeVisible()
  await expect(page.getByText(/Rotation and zoom.*not available yet/)).toBeVisible()
  await page.getByRole('link', { name: 'Learn More' }).click()
  await expect(page).toHaveURL(/#about$/)
  await page.getByRole('link', { name: 'Get Started' }).click()
  await expect(page).toHaveURL(/\/login$/)
  await expect(page.getByRole('heading', { name: 'Welcome Back' })).toBeVisible()
  await expect(page.getByRole('img', { name: 'Movers Institute of Technology and Education seal' })).toBeVisible()
  await expect(page.getByText('Movers Institute of Technology and Education').first()).toBeVisible()
  await expect(page.locator('.brand-name')).toHaveCount(0)
  await page.getByRole('tab', { name: 'Sign Up' }).click()
  await expect(page).toHaveURL(/\/activate-account$/)
  await expect(page.getByRole('heading', { name: 'Activate your account' })).toBeVisible()
  await expect(page.getByRole('img', { name: 'Movers Institute of Technology and Education seal' })).toBeVisible()
  await expect(page.locator('.brand-name')).toHaveCount(0)
})

test('landing layout keeps the seal, navigation, title, and actions reachable at real device sizes', async ({ page }) => {
  for (const [width, height] of responsiveViewports) {
    await page.setViewportSize({ width, height })
    await page.goto('/')
    await expect(page.getByRole('img', { name: 'Movers Institute of Technology and Education seal' })).toBeVisible()
    await expect(page.getByRole('heading', { name: applicationTitle })).toBeVisible()
    const measurements = await page.evaluate(() => {
      const rect = (selector: string) => {
        const element = document.querySelector(selector)
        if (!element) return null
        const { x, y, right, bottom, width, height } = element.getBoundingClientRect()
        return { x, y, right, bottom, width, height }
      }
      return {
        viewport: { width: innerWidth, height: innerHeight },
        pageWidth: document.documentElement.scrollWidth,
        header: rect('.landing-header'),
        seal: rect('.landing-identity .brand-logo-image'),
        controls: rect('.landing-controls'),
        title: rect('#landing-title'),
        getStarted: rect('.landing-start'),
        learnMore: rect('.button-outline-light'),
      }
    })
    expect(measurements.pageWidth, `horizontal overflow at ${width}×${height}`).toBeLessThanOrEqual(width)
    expect(measurements.header?.y).toBeGreaterThanOrEqual(0)
    expect(measurements.seal?.right).toBeLessThanOrEqual(measurements.controls?.x ?? 0)
    expect(measurements.title?.right).toBeLessThanOrEqual(width)
    if (height <= 500 && width <= 950) {
      expect(await page.getByRole('button', { name: 'Open site navigation' }).isVisible()).toBe(true)
      expect(measurements.getStarted?.y).toBeGreaterThanOrEqual(0)
      expect(measurements.getStarted?.bottom).toBeLessThanOrEqual(height)
      expect(measurements.learnMore?.bottom).toBeLessThanOrEqual(height)
    }
    if (width <= 430) {
      expect(await page.getByRole('button', { name: 'Open site navigation' }).isVisible()).toBe(true)
    }
  }
})

test('mobile menu opens without adding a second header row and all section links work', async ({ page }) => {
  for (const [width, height] of [[390, 844], [667, 375], [844, 390]]) {
    await page.setViewportSize({ width, height })
    await page.goto('/')
    const menuButton = page.getByRole('button', { name: 'Open site navigation' })
    await expect(menuButton).toBeVisible()
    const headerHeight = await page.locator('.landing-header').evaluate((element) => element.getBoundingClientRect().height)
    expect(headerHeight, `mobile header too tall at ${width}×${height}`).toBeLessThanOrEqual(60)
    await menuButton.click()
    await expect(page.getByRole('navigation', { name: 'Main navigation' })).toBeVisible()
    await expect(page.getByRole('button', { name: 'Close site navigation' })).toHaveAttribute('aria-expanded', 'true')
    await page.getByRole('link', { name: 'About', exact: true }).click()
    await expect(page).toHaveURL(/#about$/)
    await expect(page.getByRole('heading', { name: 'About the CSS Training Application' })).toBeVisible()
    await expect(page.getByRole('button', { name: 'Open site navigation' })).toHaveAttribute('aria-expanded', 'false')
    await page.getByRole('button', { name: 'Open site navigation' }).click()
    await page.getByRole('link', { name: 'Features', exact: true }).click()
    await expect(page).toHaveURL(/#features$/)
    await expect(page.getByRole('heading', { name: 'Explore the Learning Experience' })).toBeVisible()
    await page.getByRole('button', { name: 'Open site navigation' }).click()
    await page.getByRole('link', { name: 'Home', exact: true }).click()
    await expect(page).toHaveURL(/#home$/)
  }
})

test('login profile flow, role dashboards, and logout remain available', async ({ page }) => {
  for (const [role, path, heading] of [
    ['Student', '/student/dashboard', 'Good morning, Alex.'],
    ['Instructor', '/instructor/dashboard', 'Good morning, Jordan.'],
    ['Principal', '/principal/dashboard', 'Welcome, Taylor.'],
  ] as const) {
    await signInAs(page, role)
    await expect(page).toHaveURL(new RegExp(path.replaceAll('/', '\\/')))
    await expect(page.getByRole('heading', { name: heading })).toBeVisible()
    await expect(page.getByText('Movers Institute of Technology and Education', { exact: true })).toHaveCount(0)
    await expect(page.getByText('Computer Systems Servicing Training Application', { exact: true })).toHaveCount(0)
    await expect(page.getByRole('link', { name: 'Profile', exact: true })).toBeVisible()
    await page.getByRole('button', { name: 'Log out' }).click()
    await expect(page).toHaveURL(/\/login$/)
  }
})

test('invitation activation has a compact seal header and no visible test controls', async ({ page }) => {
  await page.goto('/login')
  await page.getByRole('tab', { name: 'Sign Up' }).click()
  await expect(page.getByRole('heading', { name: 'Activate your account' })).toBeVisible()
  await expect(page.getByLabel('Invited email')).toHaveValue('student@movers.test')
  await expect(page.getByLabel('Assigned role')).toHaveValue('CSS Student')
  await expect(page.getByText(/test invitation|invitation outcome|current invitation|unrecognized invitation|expired invitation|form checks complete/i)).toHaveCount(0)
  await expect(page.locator('.invitation-test-controls')).toHaveCount(0)
  await expect(page.getByRole('link', { name: 'Back to Login' })).toBeVisible()
  const header = await page.evaluate(() => {
    const back = document.querySelector('.activation-back-link')?.getBoundingClientRect()
    const seal = document.querySelector('.activation-header .brand-logo-image')?.getBoundingClientRect()
    return { backLeft: back?.left ?? Infinity, sealRight: seal?.right ?? -Infinity, width: innerWidth }
  })
  expect(header.backLeft).toBeLessThan(header.sealRight)
  expect(header.sealRight).toBeLessThanOrEqual(header.width)
  await expect(page.getByText('Movers Institute of Technology and Education', { exact: true })).toHaveCount(0)
  await page.getByLabel('Full name').fill('Jordan Student')
  await page.getByLabel('Create password').fill('test-only-password')
  await page.getByLabel('Confirm password').fill('test-only-password')
  await page.getByRole('button', { name: 'Activate account' }).click()
  await expect(page.getByRole('heading', { name: 'Details checked' })).toBeVisible()
  await expect(page.getByText(/no account was created/i)).toBeVisible()
  await page.getByRole('button', { name: 'Continue to login' }).click()
  await expect(page).toHaveURL(/\/login$/)
  await expect(page.getByText(/Account creation is not connected/)).toBeVisible()
})

test('invalid and expired invitation states remain available as isolated development fixtures', async ({ page }) => {
  for (const [fixture, heading] of [['invalid', 'Invitation not recognized'], ['expired', 'Invitation expired']] as const) {
    await page.goto(`/activate-account?invitationFixture=${fixture}`)
    await expect(page.getByRole('heading', { name: heading })).toBeVisible()
    await expect(page.locator('.invitation-test-controls')).toHaveCount(0)
  }
})

test('student activity links open clear UI-only previews', async ({ page }) => {
  await signInAs(page, 'Student')
  await page.getByRole('link', { name: 'Explore components' }).click()
  await expect(page.getByRole('heading', { name: 'Hardware exploration' })).toBeVisible()
  await expect(page.getByText(/Interactive 3D content and activity tracking are not available yet/)).toBeVisible()
  await page.getByRole('link', { name: 'Back to student dashboard' }).click()
  await page.getByRole('link', { name: 'Start assembly' }).click()
  await expect(page.getByRole('heading', { name: 'Guided assembly' })).toBeVisible()
  await page.getByRole('link', { name: 'Back to student dashboard' }).click()
  await page.getByRole('link', { name: 'Start disassembly' }).click()
  await expect(page.getByRole('heading', { name: 'Guided disassembly' })).toBeVisible()
})

test('instructor demo interactions cover classes, invitation, assessments, and progress', async ({ page }) => {
  await signInAs(page, 'Instructor')
  await page.getByRole('link', { name: 'My classes' }).click()
  await page.getByRole('button', { name: 'View class' }).first().click()
  await expect(page.getByRole('dialog')).toContainText('class overview')
  await page.getByRole('button', { name: 'Done' }).click()
  await page.getByRole('link', { name: 'Invite students' }).click()
  await expect(page.getByRole('dialog')).toContainText('Invite a student')
  await page.getByLabel('Invitee email').fill('fictional.student@movers.test')
  await page.getByRole('button', { name: 'Review details' }).click()
  await expect(page.getByRole('dialog')).toContainText('No email was sent')
  await page.getByRole('button', { name: 'Done' }).click()
  await page.getByRole('link', { name: 'Assign assessments' }).click()
  await page.getByRole('button', { name: 'Review assignment' }).first().click()
  await expect(page.getByRole('dialog')).toContainText('Assessment details')
  await page.getByRole('button', { name: 'Review assignment', exact: true }).last().click()
  await expect(page.getByRole('button', { name: 'Reviewed' })).toBeVisible()
  await page.getByRole('link', { name: 'Student progress' }).click()
  await expect(page.getByRole('heading', { name: 'Student progress' })).toBeVisible()
})

test('principal can review instructors and classes and preview an invite', async ({ page }) => {
  await signInAs(page, 'Principal')
  await page.getByRole('navigation', { name: 'Principal navigation' }).getByRole('link', { name: 'Invite instructor' }).click()
  await expect(page.getByRole('dialog')).toContainText('Invite an instructor')
  await page.getByLabel('Invitee email').fill('fictional.instructor@movers.test')
  await page.getByRole('button', { name: 'Review details' }).click()
  await expect(page.getByRole('dialog')).toContainText('No email was sent')
  await page.getByRole('button', { name: 'Done' }).click()
  await page.getByRole('link', { name: 'CSS classes' }).click()
  await expect(page.getByRole('heading', { name: 'CSS class overview' })).toBeVisible()
})

test('responsive landing, login, and dashboard fit requested widths', async ({ page }) => {
  for (const width of viewportWidths) {
    await page.setViewportSize({ width, height: 900 })
    await page.goto('/')
    await expect(page.getByRole('heading', { name: applicationTitle })).toBeVisible()
    let dimensions = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }))
    expect(dimensions.scroll, `landing overflow at ${width}px`).toBeLessThanOrEqual(dimensions.client)
    await page.goto('/login')
    await expect(page.getByRole('heading', { name: 'Welcome Back' })).toBeVisible()
    dimensions = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }))
    expect(dimensions.scroll, `login overflow at ${width}px`).toBeLessThanOrEqual(dimensions.client)
    await signInAs(page, 'Student')
    dimensions = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }))
    expect(dimensions.scroll, `student dashboard overflow at ${width}px`).toBeLessThanOrEqual(dimensions.client)
    if (width <= 760) {
      await page.getByRole('button', { name: 'Menu' }).click()
      await expect(page.getByRole('navigation', { name: 'Mobile role navigation' })).toBeVisible()
    }
  }
})

test('Profile opens directly in editable mode and saves display name and avatar across all roles', async ({ page }) => {
  for (const role of ['Student', 'Instructor', 'Principal'] as const) {
    await signInAs(page, role)
    await page.getByRole('link', { name: 'Profile', exact: true }).click()
    await expect(page).toHaveURL(/\/settings$/)
    await expect(page.getByRole('heading', { name: 'My Profile' })).toBeVisible()
    await expect(page.getByLabel('Full name')).toHaveAttribute('readonly', '')
    await expect(page.getByLabel('Assigned role')).toHaveValue(role === 'Student' ? 'CSS Student' : role === 'Instructor' ? 'CSS Instructor' : 'Principal')
    await expect(page.getByLabel('Email address')).toHaveValue('preview@movers.test')
    await expect(page.getByLabel('Display name')).toBeVisible()
    await expect(page.getByRole('link', { name: 'Edit profile' })).toHaveCount(0)
    await page.getByRole('button', { name: 'Choose profile avatar' }).click()
    await expect(page.getByRole('group', { name: 'Avatar appearance' })).toBeVisible()
    await page.getByRole('button', { name: 'Systems' }).click()
    const nextName = `${role} Learner`
    await page.getByLabel('Display name').fill(nextName)
    await page.getByRole('button', { name: 'Save Changes' }).click()
    await expect(page.getByRole('status')).toHaveText('Profile updated for this session.')
    await expect(page.locator('.topbar-user-name')).toHaveText(nextName)
    await expect(page.locator('.topbar-user .avatar-systems')).toBeVisible()
    await expect(page.getByRole('button', { name: 'Choose profile avatar' })).toHaveAttribute('aria-expanded', 'true')
  }
  await page.setViewportSize({ width: 390, height: 844 })
  await signInAs(page, 'Instructor')
  await page.getByRole('button', { name: 'Menu' }).click()
  await page.getByRole('link', { name: 'Profile', exact: true }).click()
  await expect(page.getByRole('heading', { name: 'My Profile' })).toBeVisible()
})

test('login email and password may be omitted for workspace navigation', async ({ page }) => {
  await page.goto('/login')
  await page.getByRole('button', { name: 'Continue' }).click()
  await expect(page).toHaveURL(/\/profile-setup$/)
  await page.getByRole('button', { name: 'Skip for now' }).click()
  await page.getByRole('link', { name: 'Profile', exact: true }).click()
  await expect(page.getByLabel('Email address')).toHaveValue('Not provided')
})

test('profile editor remains usable without overflow at portrait, landscape, tablet, and desktop sizes', async ({ page }) => {
  await signInAs(page, 'Student')
  await page.getByRole('link', { name: 'Profile', exact: true }).click()
  for (const [width, height] of responsiveViewports) {
    await page.setViewportSize({ width, height })
    const dimensions = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }))
    expect(dimensions.scroll, `profile horizontal overflow at ${width}×${height}`).toBeLessThanOrEqual(dimensions.client)
    await page.getByRole('button', { name: 'Choose profile avatar' }).click()
    const options = await page.locator('.profile-avatar-options').evaluate((element) => ({ scroll: element.scrollWidth, client: element.clientWidth }))
    expect(options.scroll, `avatar choices overflow at ${width}×${height}`).toBeLessThanOrEqual(options.client)
    const save = page.getByRole('button', { name: 'Save Changes' })
    await save.scrollIntoViewIfNeeded()
    const bounds = await save.evaluate((element) => ({ top: element.getBoundingClientRect().top, bottom: element.getBoundingClientRect().bottom, height: innerHeight }))
    expect(bounds.top).toBeGreaterThanOrEqual(0)
    expect(bounds.bottom).toBeLessThanOrEqual(bounds.height)
    await page.getByRole('button', { name: 'Choose profile avatar' }).click()
  }
})

test('login starts at a reachable top and every control scrolls into view across requested devices', async ({ page }) => {
  for (const [width, height] of responsiveViewports) {
    await page.setViewportSize({ width, height })
    await page.goto('/login')
    await expect(page.getByRole('heading', { name: 'Welcome Back' })).toBeVisible()
    await expect(page.getByRole('tab', { name: 'Login' })).toBeVisible()
    const initial = await page.evaluate(() => {
      const rect = (selector: string) => {
        const element = document.querySelector(selector)
        if (!element) return null
        const { x, y, right, bottom, width, height } = element.getBoundingClientRect()
        return { x, y, right, bottom, width, height }
      }
      return { pageWidth: document.documentElement.scrollWidth, scrollY, card: rect('.login-card'), seal: rect('.auth-brand-lockup .brand-logo-image'), heading: rect('.auth-card-heading'), tabs: rect('.auth-tabs') }
    })
    expect(initial.pageWidth, `login overflow at ${width}×${height}`).toBeLessThanOrEqual(width)
    expect(initial.scrollY).toBe(0)
    expect(initial.card?.y).toBeGreaterThanOrEqual(0)
    expect(initial.seal?.y).toBeGreaterThanOrEqual(initial.card?.y ?? 0)
    expect(initial.heading?.y).toBeGreaterThanOrEqual(initial.seal?.y ?? 0)
    expect(initial.tabs?.bottom).toBeLessThanOrEqual(height)

    for (const locator of [page.getByLabel('Email Address'), page.getByLabel('Password', { exact: true }), page.getByRole('button', { name: 'Continue' }), page.getByRole('radiogroup', { name: 'Choose a workspace' })]) {
      await locator.scrollIntoViewIfNeeded()
      const bounds = await locator.evaluate((element) => {
        const { top, bottom } = element.getBoundingClientRect()
        return { top, bottom, height: innerHeight }
      })
      expect(bounds.top, `control clipped above viewport at ${width}×${height}`).toBeGreaterThanOrEqual(0)
      expect(bounds.bottom, `control clipped below viewport at ${width}×${height}`).toBeLessThanOrEqual(bounds.height)
    }
  }
})

test('login can be completed by scrolling and tapping at every phone landscape size', async ({ page }) => {
  for (const [width, height] of [[667, 375], [844, 390], [874, 402], [932, 430]]) {
    await page.setViewportSize({ width, height })
    await page.goto('/login')
    await page.getByLabel('Email Address').fill('preview@movers.test')
    await page.getByLabel('Password', { exact: true }).fill('sample-password')
    await page.getByRole('radio', { name: 'Student', exact: true }).check()
    await page.getByRole('button', { name: 'Continue' }).scrollIntoViewIfNeeded()
    await page.getByRole('button', { name: 'Continue' }).click()
    await expect(page.getByRole('heading', { name: 'Set up your profile' })).toBeVisible()
  }
})

test('invitation activation remains scrollable on phone portrait and landscape', async ({ page }) => {
  for (const [width, height] of responsiveViewports) {
    await page.setViewportSize({ width, height })
    await page.goto('/activate-account')
    await expect(page.getByRole('heading', { name: 'Activate your account' })).toBeVisible()
    const layout = await page.evaluate(() => {
      const back = document.querySelector('.activation-back-link')?.getBoundingClientRect()
      const seal = document.querySelector('.activation-header .brand-logo-image')?.getBoundingClientRect()
      return { pageWidth: document.documentElement.scrollWidth, cardTop: document.querySelector('.activation-card')?.getBoundingClientRect().top ?? -1, backLeft: back?.left ?? Infinity, sealRight: seal?.right ?? -Infinity, viewport: innerWidth }
    })
    expect(layout.pageWidth, `activation horizontal overflow at ${width}×${height}`).toBeLessThanOrEqual(width)
    expect(layout.cardTop, `activation card clipped at ${width}×${height}`).toBeGreaterThanOrEqual(0)
    expect(layout.backLeft, `activation back link is not left aligned at ${width}×${height}`).toBeLessThan(layout.sealRight)
    expect(layout.sealRight, `activation seal is clipped at ${width}×${height}`).toBeLessThanOrEqual(layout.viewport)
    await page.getByLabel('Full name').scrollIntoViewIfNeeded()
    await page.getByLabel('Full name').fill('Jordan Student')
    await page.getByLabel('Create password').fill('test-only-password')
    await page.getByLabel('Confirm password').fill('test-only-password')
    await page.getByRole('button', { name: 'Activate account' }).scrollIntoViewIfNeeded()
    await expect(page.getByRole('button', { name: 'Activate account' })).toBeVisible()
    await page.getByRole('button', { name: 'Activate account' }).click()
    await expect(page.getByRole('heading', { name: 'Details checked' })).toBeVisible()
  }
})

test('activation, profile setup, and password recovery controls remain reachable at all requested viewports', async ({ page }) => {
  const screens = [
    { path: '/activate-account', heading: 'Activate your account', controls: ['Invited email', 'Assigned role', 'Age', 'Full name', 'Contact number', 'Create password', 'Confirm password', 'Activate account'] },
    { path: '/profile-setup', heading: 'Set up your profile', controls: ['Display name', 'Save & continue', 'Skip for now'] },
    { path: '/forgot-password', heading: 'Forgot your password?', controls: ['Account email', 'Check recovery availability'] },
  ] as const
  for (const [width, height] of responsiveViewports) {
    await page.setViewportSize({ width, height })
    for (const screen of screens) {
      await page.goto(screen.path)
      await expect(page.getByRole('heading', { name: screen.heading })).toBeVisible()
      const layout = await page.evaluate(() => ({ width: document.documentElement.scrollWidth, height: innerHeight, cardTop: document.querySelector('.auth-card')?.getBoundingClientRect().top ?? -1 }))
      expect(layout.width, `${screen.path} horizontal overflow at ${width}×${height}`).toBeLessThanOrEqual(width)
      expect(layout.cardTop, `${screen.path} top clipping at ${width}×${height}`).toBeGreaterThanOrEqual(0)
      for (const control of screen.controls) {
        const locator = control.includes('password') || control.includes('Password')
          ? page.getByLabel(control, { exact: true })
          : control === 'Activate account' || control === 'Save & continue' || control === 'Skip for now' || control === 'Check recovery availability'
            ? page.getByRole('button', { name: control, exact: true })
            : page.getByLabel(control, { exact: false })
        await locator.scrollIntoViewIfNeeded()
        const bounds = await locator.evaluate((element) => {
          const { top, bottom } = element.getBoundingClientRect()
          return { top, bottom, height: innerHeight }
        })
        expect(bounds.top, `${control} clipped above in ${screen.path} at ${width}×${height}`).toBeGreaterThanOrEqual(0)
        expect(bounds.bottom, `${control} clipped below in ${screen.path} at ${width}×${height}`).toBeLessThanOrEqual(bounds.height + 1)
      }
    }
  }
})

test('all role dashboards fit phone, landscape, tablet, and desktop layouts', async ({ page }) => {
  const dashboards = [
    ['/student/dashboard', 'STUDENT WORKSPACE'],
    ['/instructor/dashboard', 'INSTRUCTOR WORKSPACE'],
    ['/principal/dashboard', 'PRINCIPAL WORKSPACE'],
  ] as const
  for (const [width, height] of responsiveViewports) {
    await page.setViewportSize({ width, height })
    for (const [path, label] of dashboards) {
      await page.goto(path)
      await expect(page.getByText(label).first()).toBeVisible()
      const dimensions = await page.evaluate(() => ({ scroll: document.documentElement.scrollWidth, client: document.documentElement.clientWidth }))
      expect(dimensions.scroll, `${path} horizontal overflow at ${width}×${height}`).toBeLessThanOrEqual(dimensions.client)
      await expect(page.locator('.workspace-notice')).toHaveCount(0)
      await expect(page.locator('.dashboard-footer')).toHaveCount(0)
      const tableOverflows = await page.locator('.people-table').evaluateAll((tables) => tables.some((table) => table.scrollWidth > table.clientWidth + 1))
      expect(tableOverflows, `${path} roster table content overflow at ${width}×${height}`).toBe(false)
      if (width <= 760) await expect(page.getByRole('button', { name: 'Menu' })).toBeVisible()
    }
  }
})

test('user-facing screens avoid development labels while retaining factual limitations', async ({ page }) => {
  const paths = [
    '/', '/login', '/activate-account', '/forgot-password', '/profile-setup',
    '/student/dashboard', '/student/hardware', '/student/assembly', '/student/disassembly', '/student/assessments', '/student/progress',
    '/instructor/dashboard', '/instructor/classes', '/instructor/students', '/instructor/assessments', '/instructor/progress',
    '/principal/dashboard', '/principal/instructors', '/principal/classes', '/settings',
  ]
  const developmentCopy = /\b(?:demo|prototype|sample|mock|simulated|placeholder|fictional)\b|illustrative information|changes are not saved|profile changes are held|test invitation outcomes|invitation outcome|development-only|development preview|local role preview|example cases/i
  for (const path of paths) {
    await page.goto(path)
    const text = await page.locator('body').innerText()
    expect(text, `development label visible on ${path}`).not.toMatch(developmentCopy)
  }
  await page.goto('/forgot-password')
  await page.getByLabel('Account email').fill('test@movers.test')
  await page.getByRole('button', { name: 'Check recovery availability' }).click()
  await expect(page.getByRole('status')).toContainText('No message was sent')
})

test('capture CSS-UI-01E approval screenshots', async ({ page }) => {
  const output = 'artifacts/css-ui-01e'
  mkdirSync(output, { recursive: true })
  await page.setViewportSize({ width: 1440, height: 900 })
  await page.goto('/activate-account')
  await page.screenshot({ path: `${output}/invitation-activation-desktop-1440x900.png`, fullPage: true })
  await page.setViewportSize({ width: 390, height: 844 })
  await page.goto('/activate-account')
  await page.screenshot({ path: `${output}/invitation-activation-mobile-390x844.png`, fullPage: true })

  await page.setViewportSize({ width: 1440, height: 900 })
  await signInAs(page, 'Student')
  await page.getByRole('link', { name: 'Profile', exact: true }).click()
  await expect(page).toHaveURL(/\/settings$/)
  await expect(page.getByRole('heading', { name: 'My Profile' })).toBeVisible()
  await page.screenshot({ path: `${output}/profile-settings-desktop-1440x900.png`, fullPage: true })
  await page.setViewportSize({ width: 390, height: 844 })
  await page.screenshot({ path: `${output}/profile-settings-mobile-390x844.png`, fullPage: true })

  await page.setViewportSize({ width: 1440, height: 900 })
  await signInAs(page, 'Student')
  await page.setViewportSize({ width: 390, height: 844 })
  await page.screenshot({ path: `${output}/student-dashboard-mobile-390x844.png`, fullPage: true })
  await page.setViewportSize({ width: 1440, height: 900 })
  await signInAs(page, 'Instructor')
  await page.setViewportSize({ width: 390, height: 844 })
  await page.screenshot({ path: `${output}/instructor-dashboard-mobile-390x844.png`, fullPage: true })
  await page.setViewportSize({ width: 1440, height: 900 })
  await signInAs(page, 'Principal')
  await expect(page.getByRole('heading', { name: 'Welcome, Taylor.' })).toBeVisible()
  await page.screenshot({ path: `${output}/principal-dashboard-desktop-1440x900.png`, fullPage: true })
})
