# Project Instructions for Codex

- Read `docs/project-context.md`, `docs/system-flow.md`, and `docs/architecture.md` before making substantial product or architecture changes.
- Respect the approved CSS research scope and role hierarchy.
- Audit existing files and architecture before editing. Preserve existing work and avoid replacing unrelated project assets.
- Keep interfaces mobile-first, accessible, compact, and professional. Use the established navy, charcoal, slate, soft-white, and teal tokens.
- Treat authentication, invitations, assessments, VR compatibility, and 3D behavior as simulated or future requirements until actually implemented and verified.
- Never automatically add multiplayer, walkable lab navigation, avatar gameplay, complex troubleshooting, certification, or school-management features.
- Keep mock data clearly labeled. Do not use real student personal information or credentials.
- Preserve the React/TypeScript, Vite, Tailwind CSS v4, React Router, and npm architecture unless a task gives a concrete reason to change it.
- Do not add Three.js, backend services, databases, SMTP, or mobile packaging unless the user requests that phase.
- Verify relevant changes with TypeScript validation, production build, linting, and the appropriate Playwright checks. Report anything not run or not verified.
- Do not commit, push, merge, or deploy unless explicitly requested.
