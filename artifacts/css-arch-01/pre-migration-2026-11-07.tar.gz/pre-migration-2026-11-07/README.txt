Pre-migration React/TypeScript source snapshot for CSS-ARCH-01.
Captured before vanilla HTML, CSS, and JavaScript implementation on 2026-11-07.
The existing UI baseline passed `npm run test:e2e` with 20 tests before this archive was created.
This archive is preserved for comparison and rollback; it is not part of the shipped app.
