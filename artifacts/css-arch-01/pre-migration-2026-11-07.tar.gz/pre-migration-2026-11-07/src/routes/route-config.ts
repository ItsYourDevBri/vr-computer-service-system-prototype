import type { DemoRole } from '../app/prototype-config'

export type DashboardLink = {
  label: string
  path: string
  icon: string
}

export const dashboardNavigation: Record<DemoRole, DashboardLink[]> = {
  student: [
    { label: 'Overview', path: '/student/dashboard', icon: 'layout' },
    { label: 'Hardware exploration', path: '/student/hardware', icon: 'cpu' },
    { label: 'Guided assembly', path: '/student/assembly', icon: 'wrench' },
    { label: 'Guided disassembly', path: '/student/disassembly', icon: 'package' },
    { label: 'Assessments', path: '/student/assessments', icon: 'clipboard' },
    { label: 'My progress', path: '/student/progress', icon: 'chart' },
  ],
  instructor: [
    { label: 'Overview', path: '/instructor/dashboard', icon: 'layout' },
    { label: 'My classes', path: '/instructor/classes', icon: 'class' },
    { label: 'Invite students', path: '/instructor/students?invite=1', icon: 'user-plus' },
    { label: 'Student list', path: '/instructor/students', icon: 'users' },
    { label: 'Assign assessments', path: '/instructor/assessments', icon: 'clipboard' },
    { label: 'Student progress', path: '/instructor/progress', icon: 'chart' },
  ],
  principal: [
    { label: 'Overview', path: '/principal/dashboard', icon: 'layout' },
    { label: 'Invite instructor', path: '/principal/instructors?invite=1', icon: 'user-plus' },
    { label: 'Instructor list', path: '/principal/instructors', icon: 'users' },
    { label: 'CSS classes', path: '/principal/classes', icon: 'class' },
  ],
}
