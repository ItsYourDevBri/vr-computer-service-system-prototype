import { Navigate, Routes, Route, useLocation } from 'react-router'
import { useEffect, type ReactNode } from 'react'
import { usePrototypeState } from './app/use-prototype-state'
import { PrototypeStateProvider } from './app/prototype-state'
import { DashboardLayout } from './components/DashboardLayout'
import { ActivateAccountPage } from './pages/ActivateAccountPage'
import { LoginPage } from './pages/LoginPage'
import { ProfileSetupPage } from './pages/ProfileSetupPage'
import { ForgotPasswordPage } from './pages/ForgotPasswordPage'
import { LandingPage } from './pages/LandingPage'
import { StudentActivityPreview, StudentAssessmentsPage, StudentDashboardPage, StudentProgressPage } from './pages/StudentDashboardPage'
import {
  InstructorAssessmentsPage, InstructorClassesPage, InstructorDashboardPage,
  InstructorProgressPage, InstructorStudentsPage, PrincipalClassesPage,
  PrincipalDashboardPage, PrincipalInstructorsPage, ProfileSettingsPage,
} from './pages/ManagementPages'

function StudentShell({ children }: { children: ReactNode }) {
  return <DashboardLayout role="student">{children}</DashboardLayout>
}
function InstructorShell({ children }: { children: ReactNode }) {
  return <DashboardLayout role="instructor">{children}</DashboardLayout>
}
function PrincipalShell({ children }: { children: ReactNode }) {
  return <DashboardLayout role="principal">{children}</DashboardLayout>
}
function ProfileSettingsRoute() {
  const { role } = usePrototypeState()
  return <DashboardLayout role={role}><ProfileSettingsPage /></DashboardLayout>
}

function ScrollToTop() {
  const { pathname } = useLocation()
  useEffect(() => { window.scrollTo({ top: 0, left: 0, behavior: 'instant' }) }, [pathname])
  return null
}

function App() {
  return <PrototypeStateProvider><ScrollToTop /><Routes>
    <Route path="/" element={<LandingPage />} />
    <Route path="/login" element={<LoginPage />} />
    <Route path="/activate-account" element={<ActivateAccountPage />} />
    <Route path="/profile-setup" element={<ProfileSetupPage />} />

    <Route path="/student/dashboard" element={<StudentShell><StudentDashboardPage /></StudentShell>} />
    <Route path="/student/hardware" element={<StudentShell><StudentActivityPreview title="Hardware exploration" type="hardware" /></StudentShell>} />
    <Route path="/student/assembly" element={<StudentShell><StudentActivityPreview title="Guided assembly" type="assembly" /></StudentShell>} />
    <Route path="/student/disassembly" element={<StudentShell><StudentActivityPreview title="Guided disassembly" type="disassembly" /></StudentShell>} />
    <Route path="/student/assessments" element={<StudentShell><StudentAssessmentsPage /></StudentShell>} />
    <Route path="/student/progress" element={<StudentShell><StudentProgressPage /></StudentShell>} />

    <Route path="/instructor/dashboard" element={<InstructorShell><InstructorDashboardPage /></InstructorShell>} />
    <Route path="/instructor/classes" element={<InstructorShell><InstructorClassesPage /></InstructorShell>} />
    <Route path="/instructor/students" element={<InstructorShell><InstructorStudentsPage /></InstructorShell>} />
    <Route path="/instructor/assessments" element={<InstructorShell><InstructorAssessmentsPage /></InstructorShell>} />
    <Route path="/instructor/progress" element={<InstructorShell><InstructorProgressPage /></InstructorShell>} />

    <Route path="/principal/dashboard" element={<PrincipalShell><PrincipalDashboardPage /></PrincipalShell>} />
    <Route path="/principal/instructors" element={<PrincipalShell><PrincipalInstructorsPage /></PrincipalShell>} />
    <Route path="/principal/classes" element={<PrincipalShell><PrincipalClassesPage /></PrincipalShell>} />
    <Route path="/settings" element={<ProfileSettingsRoute />} />
    <Route path="/forgot-password" element={<ForgotPasswordPage />} />
    <Route path="*" element={<Navigate to="/login" replace />} />
  </Routes></PrototypeStateProvider>
}

export default App
