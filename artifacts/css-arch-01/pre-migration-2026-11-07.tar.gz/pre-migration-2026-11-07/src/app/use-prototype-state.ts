import { useContext } from 'react'
import { PrototypeStateContext } from './prototype-context'

export function usePrototypeState() {
  const state = useContext(PrototypeStateContext)
  if (!state) throw new Error('usePrototypeState must be used within PrototypeStateProvider')
  return state
}
