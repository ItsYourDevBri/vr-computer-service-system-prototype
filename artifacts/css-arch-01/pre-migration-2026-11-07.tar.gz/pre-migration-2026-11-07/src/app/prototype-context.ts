import { createContext } from 'react'
import type { DemoRole } from './prototype-config'

export type PrototypeStateValue = {
  role: DemoRole
  fullName: string
  displayName: string
  emailAddress: string
  avatarStyle: 'initials' | 'systems' | 'teal'
  chooseRole: (role: DemoRole, emailAddress?: string) => void
  finishProfile: (role: DemoRole, displayName?: string, avatarStyle?: PrototypeStateValue['avatarStyle']) => void
  updateProfile: (displayName: string, avatarStyle: PrototypeStateValue['avatarStyle']) => void
  logout: () => void
}

export const PrototypeStateContext = createContext<PrototypeStateValue | null>(null)
