import { useMemo, useState, type ReactNode } from 'react'
import { PrototypeStateContext } from './prototype-context'
import type { DemoRole, } from './prototype-config'
import type { PrototypeStateValue } from './prototype-context'

const defaultNames: Record<DemoRole, string> = {
  student: 'Alex Morgan',
  instructor: 'Jordan Lee',
  principal: 'Taylor Reed',
}

export function PrototypeStateProvider({ children }: { children: ReactNode }) {
  const [role, setRole] = useState<DemoRole>('student')
  const [fullName, setFullName] = useState(defaultNames.student)
  const [displayName, setDisplayName] = useState(defaultNames.student)
  const [emailAddress, setEmailAddress] = useState('')
  const [avatarStyle, setAvatarStyle] = useState<PrototypeStateValue['avatarStyle']>('initials')

  const value = useMemo<PrototypeStateValue>(() => ({
    role,
    fullName,
    displayName,
    emailAddress,
    avatarStyle,
    chooseRole: (nextRole, nextEmailAddress = '') => {
      setRole(nextRole)
      setFullName(defaultNames[nextRole])
      setDisplayName(defaultNames[nextRole])
      setEmailAddress(nextEmailAddress.trim())
      setAvatarStyle('initials')
    },
    finishProfile: (nextRole, nextName, nextAvatar) => {
      setRole(nextRole)
      setFullName((current) => current || defaultNames[nextRole])
      setDisplayName(nextName?.trim() || defaultNames[nextRole])
      setAvatarStyle(nextAvatar ?? 'initials')
    },
    updateProfile: (nextName, nextAvatar) => {
      setDisplayName(nextName.trim())
      setAvatarStyle(nextAvatar)
    },
    logout: () => {
      setRole('student')
      setFullName(defaultNames.student)
      setDisplayName(defaultNames.student)
      setEmailAddress('')
      setAvatarStyle('initials')
    },
  }), [avatarStyle, displayName, emailAddress, fullName, role])

  return <PrototypeStateContext.Provider value={value}>{children}</PrototypeStateContext.Provider>
}
