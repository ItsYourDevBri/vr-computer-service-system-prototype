export type DemoRole = 'student' | 'instructor' | 'principal'

export const roleLabels: Record<DemoRole, string> = {
  student: 'CSS Student',
  instructor: 'CSS Instructor',
  principal: 'Principal',
}

export const dashboardPaths: Record<DemoRole, string> = {
  student: '/student/dashboard',
  instructor: '/instructor/dashboard',
  principal: '/principal/dashboard',
}
