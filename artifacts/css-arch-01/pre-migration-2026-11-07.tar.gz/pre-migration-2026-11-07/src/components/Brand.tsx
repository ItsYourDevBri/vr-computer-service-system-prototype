import { Link } from 'react-router'

export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link className={`brand-lockup${compact ? ' brand-lockup-compact' : ''}`} to="/login" aria-label="Movers Institute of Technology and Education home">
      <img className="brand-logo-image" src="/images/mite-school-seal.jpg" alt="Movers Institute of Technology and Education seal" />
    </Link>
  )
}
