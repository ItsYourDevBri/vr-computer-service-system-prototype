import {
  ArrowUpRight, BookOpen, ChartNoAxesColumnIncreasing, ClipboardCheck, Cpu,
  DoorOpen, LayoutDashboard, Menu, PackageOpen, Settings, Users, UserPlus, Wrench, X,
} from 'lucide-react'
import { useState, type ReactNode } from 'react'
import { Link, NavLink, useLocation, useNavigate } from 'react-router'
import { dashboardNavigation } from '../routes/route-config'
import { roleLabels, dashboardPaths, type DemoRole } from '../app/prototype-config'
import { usePrototypeState } from '../app/use-prototype-state'
import { Brand } from './Brand'

const icons = {
  layout: LayoutDashboard, cpu: Cpu, wrench: Wrench, package: PackageOpen,
  clipboard: ClipboardCheck, chart: ChartNoAxesColumnIncreasing, class: BookOpen,
  'user-plus': UserPlus, users: Users,
}

export function DashboardLayout({ role, children }: { role: DemoRole; children: ReactNode }) {
  const { pathname } = useLocation()
  const navigate = useNavigate()
  const { displayName, avatarStyle, logout } = usePrototypeState()
  const [mobileNavOpen, setMobileNavOpen] = useState(false)
  const links = dashboardNavigation[role]
  const roleName = roleLabels[role]
  const initials = displayName.split(' ').map((part) => part[0]).slice(0, 2).join('').toUpperCase()

  const signOut = () => {
    logout()
    navigate('/login')
  }

  return (
    <div className="dashboard-app">
      <aside className="sidebar">
        <div className="sidebar-brand"><Brand compact /></div>
        <div className="sidebar-role"><span className="role-indicator" /><strong>{roleName}</strong></div>
        <nav className="side-navigation" aria-label={`${roleName} navigation`}>
          <p className="nav-caption">WORKSPACE</p>
          {links.map((item) => {
            const Icon = icons[item.icon as keyof typeof icons]
            const itemPath = item.path.split('?')[0]
            const active = itemPath === pathname
            return <NavLink key={item.path} to={item.path} className={`side-link${active ? ' is-active' : ''}`} aria-current={active ? 'page' : undefined}>
              <Icon size={17} strokeWidth={1.75} aria-hidden="true" /><span>{item.label}</span>
            </NavLink>
          })}
        </nav>
        <div className="sidebar-bottom">
          <Link className={`side-link${pathname === '/settings' ? ' is-active' : ''}`} to="/settings"><Settings size={17} /><span>Profile</span></Link>
          <button className="side-link signout-link" type="button" onClick={signOut}><DoorOpen size={17} /><span>Log out</span></button>
        </div>
      </aside>

      <div className="dashboard-main-column">
        <header className="dashboard-topbar">
          <button className="mobile-menu-button" type="button" onClick={() => setMobileNavOpen((open) => !open)} aria-expanded={mobileNavOpen} aria-controls="mobile-navigation">
            {mobileNavOpen ? <X size={20} /> : <Menu size={20} />}<span>{mobileNavOpen ? 'Close menu' : 'Menu'}</span>
          </button>
          <div className="breadcrumbs"><span>CSS TRAINING</span><span className="breadcrumb-slash">/</span><strong>{roleName}</strong></div>
          <div className="topbar-user"><span className={`avatar avatar-small avatar-${avatarStyle}`}>{avatarStyle === 'systems' ? <Cpu size={14} /> : avatarStyle === 'teal' ? <span /> : initials}</span><span className="topbar-user-name">{displayName}</span></div>
        </header>
        {mobileNavOpen && <nav className="mobile-navigation" id="mobile-navigation" aria-label="Mobile role navigation">
          {links.map((item) => {
            const Icon = icons[item.icon as keyof typeof icons]
            return <NavLink key={item.path} to={item.path} onClick={() => setMobileNavOpen(false)} className="mobile-nav-link"><Icon size={17} />{item.label}<ArrowUpRight size={14} className="mobile-nav-arrow" /></NavLink>
          })}
          <Link to="/settings" onClick={() => setMobileNavOpen(false)} className="mobile-nav-link"><Settings size={17} />Profile</Link>
          <button type="button" className="mobile-nav-link" onClick={signOut}><DoorOpen size={17} />Log out</button>
        </nav>}
        <main className="dashboard-content">
          {children}
        </main>
      </div>
    </div>
  )
}

export function DashboardFrame({ role, children }: { role: DemoRole; children: ReactNode }) {
  return <DashboardLayout role={role}>{children}</DashboardLayout>
}

export function DashboardHomeLink({ role, children }: { role: DemoRole; children: ReactNode }) {
  return <Link className="subtle-link" to={dashboardPaths[role]}>{children}</Link>
}
