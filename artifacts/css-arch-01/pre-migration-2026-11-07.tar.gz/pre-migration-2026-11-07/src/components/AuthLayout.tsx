import type { ReactNode } from 'react'

export function AuthLayout({ children, compact = false }: { children: ReactNode; compact?: boolean }) {
  return <main className={`auth-scene${compact ? ' auth-scene-compact' : ''}`}>
    <div className="cinematic-photo" aria-hidden="true" />
    <div className="auth-center-content">{children}</div>
  </main>
}
