import { ArrowRight, Check, Cpu, SkipForward, UserRound } from 'lucide-react'
import { useState } from 'react'
import { useNavigate } from 'react-router'
import { dashboardPaths, roleLabels } from '../app/prototype-config'
import { usePrototypeState } from '../app/use-prototype-state'
import { AuthLayout } from '../components/AuthLayout'
import { Brand } from '../components/Brand'

const avatarChoices = [
  { id: 'initials', label: 'Initials', icon: UserRound },
  { id: 'systems', label: 'Systems', icon: Cpu },
  { id: 'teal', label: 'Teal', icon: Check },
]

export function ProfileSetupPage() {
  const { role, displayName, finishProfile } = usePrototypeState()
  const [name, setName] = useState(displayName)
  const [avatar, setAvatar] = useState('initials')
  const navigate = useNavigate()

  const continueToDashboard = (saveName: boolean) => {
    finishProfile(role, saveName ? name : undefined, saveName ? avatar as 'initials' | 'systems' | 'teal' : undefined)
    navigate(dashboardPaths[role])
  }

  return <AuthLayout compact>
    <div className="auth-card profile-card">
      <div className="auth-brand-lockup"><Brand compact /><p>Movers Institute of Technology and Education</p></div>
      <div className="auth-card-heading">
        <h2>Set up your profile</h2>
        <p>Personalize your learning experience. You can change this later.</p>
      </div>
      <div className="avatar-picker-block">
        <span className="field-label">Profile avatar</span>
        <div className="profile-preview-row">
          <div className={`avatar avatar-preview avatar-${avatar}`}>{avatar === 'initials' ? name.trim().split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase() || 'A' : avatar === 'systems' ? <Cpu size={22} /> : <span />}</div>
          <div><strong>{name.trim() || 'Your display name'}</strong><span>{roleLabels[role]}</span></div>
        </div>
        <div className="avatar-options" role="radiogroup" aria-label="Avatar style">
          {avatarChoices.map(({ id, label, icon: Icon }) => <button type="button" className={`avatar-option${avatar === id ? ' is-selected' : ''}`} key={id} onClick={() => setAvatar(id)} aria-pressed={avatar === id}><Icon size={15} />{label}</button>)}
        </div>
      </div>
      <div className="form-field profile-name-field"><label htmlFor="profile-name" className="field-label">Display name <span className="label-hint">Optional</span></label><input className="text-input" id="profile-name" maxLength={40} value={name} onChange={(event) => setName(event.target.value)} placeholder="How should we address you?" /></div>
      <div className="profile-actions"><button className="button button-primary button-full" type="button" onClick={() => continueToDashboard(true)}>Save & continue <ArrowRight size={16} /></button><button className="button button-quiet button-full" type="button" onClick={() => continueToDashboard(false)}><SkipForward size={15} /> Skip for now</button></div>
    </div>
  </AuthLayout>
}
