import {
  ArrowRight, BookOpen, Check, ChevronRight, ClipboardCheck, Cpu, Mail,
  Plus, Search, Users, UserRound,
} from 'lucide-react'
import { useState, type FormEvent, type ReactNode } from 'react'
import { Link, useSearchParams } from 'react-router'
import { roleLabels } from '../app/prototype-config'
import { usePrototypeState } from '../app/use-prototype-state'
import { DemoForm, Modal } from '../components/Modal'
import { PageHeading, SectionHeading } from '../components/PageHeading'

const students = [
  { name: 'Mika Santos', email: 'mika.santos@movers.test', className: 'CSS 11 · Section A', progress: 72, status: 'Active' },
  { name: 'Noah Reyes', email: 'noah.reyes@movers.test', className: 'CSS 11 · Section A', progress: 48, status: 'Active' },
  { name: 'Ava Cruz', email: 'ava.cruz@movers.test', className: 'CSS 11 · Section B', progress: 26, status: 'Invited' },
]
const classes = [
  { name: 'CSS 11 · Section A', code: 'CSS-11A', students: 18, completion: '64%', next: 'Component identification' },
  { name: 'CSS 11 · Section B', code: 'CSS-11B', students: 16, completion: '42%', next: 'System assembly sequence' },
]
const assessments = [
  { name: 'Component identification', category: 'Hardware knowledge', steps: '6 items', assigned: '12 students' },
  { name: 'System assembly sequence', category: 'Procedural assessment', steps: '8 steps', assigned: '18 students' },
  { name: 'Safe disassembly sequence', category: 'Procedural assessment', steps: '7 steps', assigned: 'Not assigned' },
]
const instructors = [
  { name: 'Jordan Lee', email: 'jordan.lee@movers.test', classes: 2, status: 'Active' },
  { name: 'Sam Rivera', email: 'sam.rivera@movers.test', classes: 1, status: 'Active' },
  { name: 'Casey Lim', email: 'casey.lim@movers.test', classes: 0, status: 'Invitation sent' },
]

function MetricCard({ label, value, note, icon }: { label: string; value: string; note: string; icon: ReactNode }) {
  return <article className="metric-card"><span className="metric-icon">{icon}</span><span className="metric-note">{note}</span><strong>{value}</strong><span className="metric-label">{label}</span></article>
}

export function InstructorDashboardPage() {
  const { displayName } = usePrototypeState()
  const first = displayName.split(' ')[0]
  return <div className="dashboard-page">
    <PageHeading eyebrow="INSTRUCTOR WORKSPACE" title={`Good morning, ${first}.`} description="A clear view of your classes, learner activity, and next teaching actions." action={<Link className="button button-primary button-small" to="/instructor/students?invite=1"><Plus size={15} /> Invite students</Link>} />
    <div className="metric-grid"><MetricCard label="Your classes" value="2" note="Current term" icon={<BookOpen size={18} />} /><MetricCard label="Students" value="34" note="Class roster" icon={<Users size={18} />} /><MetricCard label="Assessment activity" value="68%" note="Activity overview" icon={<ClipboardCheck size={18} />} /></div>
    <div className="management-grid instructor-overview-grid">
      <section className="content-panel"><SectionHeading title="Your classes" detail="Open a class overview to see roster details." action={<Link className="subtle-link" to="/instructor/classes">View classes <ArrowRight size={14} /></Link>} />
        <div className="class-list">{classes.map((item) => <Link className="class-row" to="/instructor/classes" key={item.code}><span className="class-symbol"><BookOpen size={18} /></span><span className="class-row-copy"><strong>{item.name}</strong><small>{item.students} students · {item.code}</small></span><span className="class-progress"><span>{item.completion} activity</span><i><b style={{ width: item.completion }} /></i></span><ChevronRight size={16} /></Link>)}</div>
      </section>
      <section className="content-panel next-action-panel"><span className="action-eyebrow">TEACHING TOOL</span><div className="action-icon"><ClipboardCheck size={21} /></div><h2>Prepare an assessment</h2><p>Choose from predefined hardware and procedural activities for your classes.</p><Link className="button button-secondary button-small" to="/instructor/assessments">Browse assessments <ArrowRight size={14} /></Link></section>
    </div>
    <section className="content-panel"><SectionHeading title="Student activity" detail="Recent learner activity across your classes." action={<Link className="subtle-link" to="/instructor/progress">View progress <ArrowRight size={14} /></Link>} /><PeopleTable people={students.slice(0, 2)} mode="student" /></section>
  </div>
}

export function InstructorClassesPage() {
  const [selected, setSelected] = useState<(typeof classes)[number] | null>(null)
  return <div className="dashboard-page"><PageHeading eyebrow="INSTRUCTOR WORKSPACE" title="My classes" description="Review classes assigned to this instructor." />
    <section className="content-panel"><SectionHeading title="Class overview" detail="Review class activity and upcoming assessments." /><div className="class-card-grid">{classes.map((item) => <article className="class-card" key={item.code}><div className="class-card-heading"><span className="class-symbol"><BookOpen size={18} /></span><span className="status-badge status-active">ACTIVE</span></div><h2>{item.name}</h2><p>{item.code} <span>·</span> {item.students} students</p><div className="class-card-meter"><span>Activity overview <strong>{item.completion}</strong></span><i><b style={{ width: item.completion }} /></i></div><div className="class-card-footer"><span>Next assessment<br /><strong>{item.next}</strong></span><button className="button button-secondary button-small" type="button" onClick={() => setSelected(item)}>View class</button></div></article>)}</div></section>
    {selected && <Modal title={selected.name} description={`${selected.code} · class overview`} onClose={() => setSelected(null)}><div className="modal-summary"><p><strong>{selected.students} students</strong></p><div className="modal-stat-line"><span>Activity overview</span><strong>{selected.completion}</strong></div><div className="modal-stat-line"><span>Next assessment</span><strong>{selected.next}</strong></div></div><button className="button button-primary button-full" type="button" onClick={() => setSelected(null)}>Done</button></Modal>}
  </div>
}

export function InstructorStudentsPage() {
  const [query, setQuery] = useState('')
  const [modalOpen, setModalOpen] = useState(false)
  const [invited, setInvited] = useState(false)
  const [searchParams, setSearchParams] = useSearchParams()
  const [selected, setSelected] = useState<(typeof students)[number] | null>(null)
  const shouldInvite = searchParams.get('invite') === '1'
  const openInvite = () => { setModalOpen(true); setInvited(false) }
  const closeInvite = () => { setModalOpen(false); if (shouldInvite) setSearchParams({}) }
  const visible = students.filter((student) => `${student.name} ${student.email} ${student.className}`.toLowerCase().includes(query.toLowerCase()))
  return <div className="dashboard-page"><PageHeading eyebrow="INSTRUCTOR WORKSPACE" title="Student list" description="Review your class roster or prepare invitation details." action={<button className="button button-primary button-small" type="button" onClick={openInvite}><Plus size={15} /> Invite student</button>} />
    <section className="content-panel"><div className="list-toolbar"><SectionHeading title="Students" detail="Class roster" /><label className="search-field"><Search size={16} /><input aria-label="Search students" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search students" /></label></div><PeopleTable people={visible} mode="student" onSelect={setSelected} /></section>
    {(modalOpen || shouldInvite) && <InviteModal role="student" complete={invited} onSubmit={() => setInvited(true)} onClose={closeInvite} />}
    {selected && <PersonModal person={selected} onClose={() => setSelected(null)} />}
  </div>
}

export function InstructorAssessmentsPage() {
  const [selected, setSelected] = useState<(typeof assessments)[number] | null>(null)
  const [reviewed, setReviewed] = useState<string[]>([])
  return <div className="dashboard-page"><PageHeading eyebrow="INSTRUCTOR WORKSPACE" title="Assign assessments" description="Review the predefined activities available for classes." />
    <section className="content-panel"><SectionHeading title="Assessment library" detail="Predefined hardware and procedural activities." /><div className="assessment-grid">{assessments.map((item) => <article className="assessment-card" key={item.name}><span className="assessment-icon"><ClipboardCheck size={18} /></span><p className="card-meta">{item.category}</p><h2>{item.name}</h2><p>{item.steps} · {item.assigned}</p><button className="button button-secondary button-small" type="button" onClick={() => setSelected(item)}>{reviewed.includes(item.name) ? 'Reviewed' : 'Review assignment'} <ArrowRight size={14} /></button></article>)}</div></section>
    {selected && <Modal title={selected.name} description="Assessment details" onClose={() => setSelected(null)}><div className="modal-summary"><p>Review <strong>{selected.name}</strong> before assigning it to a class.</p><label className="field-label" htmlFor="class-select">Class</label><select className="text-input" id="class-select"><option>CSS 11 · Section A</option><option>CSS 11 · Section B</option></select><p className="privacy-note">{selected.category} · {selected.steps}</p></div><button className="button button-primary button-full" type="button" onClick={() => { setReviewed((current) => [...new Set([...current, selected.name])]); setSelected(null) }}>Review assignment <Check size={15} /></button></Modal>}
  </div>
}

export function InstructorProgressPage() {
  const [selected, setSelected] = useState<(typeof students)[number] | null>(null)
  return <div className="dashboard-page"><PageHeading eyebrow="INSTRUCTOR WORKSPACE" title="Student progress" description="Review learning activity and assessment progress." />
    <div className="metric-grid"><MetricCard label="Students with activity" value="2" note="Activity overview" icon={<Users size={18} />} /><MetricCard label="Average completion" value="60%" note="Current period" icon={<ClipboardCheck size={18} />} /><MetricCard label="Assessments" value="3" note="Procedural activities" icon={<BookOpen size={18} />} /></div>
    <section className="content-panel"><SectionHeading title="Learner overview" detail="Select a learner to review activity details." /><PeopleTable people={students} mode="student" onSelect={setSelected} /></section>
    {selected && <PersonModal person={selected} onClose={() => setSelected(null)} />}
  </div>
}

export function PrincipalDashboardPage() {
  const { displayName } = usePrototypeState()
  return <div className="dashboard-page"><PageHeading eyebrow="PRINCIPAL WORKSPACE" title={`Welcome, ${displayName.split(' ')[0]}.`} description="Manage CSS instructor access and review a concise class overview." action={<Link className="button button-primary button-small" to="/principal/instructors?invite=1"><Plus size={15} /> Invite instructor</Link>} />
    <div className="metric-grid"><MetricCard label="CSS instructors" value="3" note="Directory" icon={<UserRound size={18} />} /><MetricCard label="Active classes" value="2" note="Current term" icon={<BookOpen size={18} />} /><MetricCard label="Learner participation" value="58%" note="Activity overview" icon={<Users size={18} />} /></div>
    <div className="management-grid principal-overview-grid"><section className="content-panel"><SectionHeading title="Instructor accounts" detail="Instructor directory." action={<Link className="subtle-link" to="/principal/instructors">Manage instructors <ArrowRight size={14} /></Link>} /><PeopleTable people={instructors} mode="instructor" /></section><section className="content-panel"><SectionHeading title="CSS class overview" detail="Class activity." action={<Link className="subtle-link" to="/principal/classes">View classes <ArrowRight size={14} /></Link>} /><div className="principal-class-list">{classes.map((item) => <div className="principal-class-row" key={item.code}><span><strong>{item.name}</strong><small>{item.students} students</small></span><b>{item.completion}</b></div>)}</div></section></div>
  </div>
}

export function PrincipalInstructorsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const [modalOpen, setModalOpen] = useState(false)
  const [complete, setComplete] = useState(false)
  const [selected, setSelected] = useState<(typeof instructors)[number] | null>(null)
  const shouldInvite = searchParams.get('invite') === '1'
  const openInvite = () => { setModalOpen(true); setComplete(false) }
  const closeInvite = () => { setModalOpen(false); if (searchParams.get('invite')) setSearchParams({}) }
  return <div className="dashboard-page"><PageHeading eyebrow="PRINCIPAL WORKSPACE" title="Manage instructors" description="Review the CSS instructor directory or prepare invitation details." action={<button className="button button-primary button-small" onClick={openInvite} type="button"><Plus size={15} /> Invite instructor</button>} />
    <section className="content-panel"><SectionHeading title="Instructor directory" detail="Instructor records" /><PeopleTable people={instructors} mode="instructor" onSelect={setSelected} /></section>
    {(modalOpen || shouldInvite) && <InviteModal role="instructor" complete={complete} onSubmit={() => setComplete(true)} onClose={closeInvite} />}
    {selected && <PersonModal person={selected} onClose={() => setSelected(null)} />}
  </div>
}

export function PrincipalClassesPage() {
  return <div className="dashboard-page"><PageHeading eyebrow="PRINCIPAL WORKSPACE" title="CSS class overview" description="A concise institutional view of CSS classes and participation." />
    <div className="metric-grid"><MetricCard label="Classes" value="2" note="Current term" icon={<BookOpen size={18} />} /><MetricCard label="Enrolled students" value="34" note="Enrollment overview" icon={<Users size={18} />} /><MetricCard label="Instructors" value="3" note="Directory" icon={<UserRound size={18} />} /></div>
    <section className="content-panel"><SectionHeading title="Class activity" detail="Participation across CSS classes." /><div className="principal-class-table"><div className="principal-table-head"><span>CLASS</span><span>INSTRUCTOR</span><span>STUDENTS</span><span>ACTIVITY OVERVIEW</span></div>{classes.map((item, index) => <div className="principal-table-row" key={item.code}><strong>{item.name}</strong><span>{instructors[index % instructors.length].name}</span><span>{item.students}</span><span className="class-progress"><i><b style={{ width: item.completion }} /></i>{item.completion}</span></div>)}</div></section>
  </div>
}

export function ProfileSettingsPage() {
  const { fullName, displayName, emailAddress, role, avatarStyle, updateProfile } = usePrototypeState()
  const [name, setName] = useState(displayName)
  const [avatar, setAvatar] = useState(avatarStyle)
  const [avatarPickerOpen, setAvatarPickerOpen] = useState(false)
  const [error, setError] = useState('')
  const [saved, setSaved] = useState(false)
  const initials = name.trim().split(/\s+/).map((part) => part[0]).slice(0, 2).join('').toUpperCase() || 'A'

  const saveProfile = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (!name.trim()) {
      setError('Enter a display name to continue.')
      setSaved(false)
      return
    }
    updateProfile(name.trim(), avatar)
    setName(name.trim())
    setError('')
    setSaved(true)
  }

  return <div className="dashboard-page profile-settings-page">
    <PageHeading title="My Profile" description="Manage your personal information and preferences." />
    <form className="profile-settings-form" onSubmit={saveProfile}>
      <section className="content-panel profile-editor-panel" aria-label="Profile details">
        <div className="profile-avatar-column">
          <button className="profile-avatar-trigger" type="button" aria-label="Choose profile avatar" aria-expanded={avatarPickerOpen} aria-controls="profile-avatar-options" onClick={() => setAvatarPickerOpen((open) => !open)}>
            <span className={`avatar avatar-profile avatar-${avatar}`}>{avatar === 'initials' ? initials : avatar === 'systems' ? <Cpu size={26} /> : <span />}</span>
            <span>Change avatar</span>
          </button>
          {avatarPickerOpen && <div className="avatar-options profile-avatar-options" id="profile-avatar-options" role="group" aria-label="Avatar appearance">
            <button className={`avatar-option${avatar === 'initials' ? ' is-selected' : ''}`} type="button" aria-pressed={avatar === 'initials'} onClick={() => setAvatar('initials')}><UserRound size={15} />Initials</button>
            <button className={`avatar-option${avatar === 'systems' ? ' is-selected' : ''}`} type="button" aria-pressed={avatar === 'systems'} onClick={() => setAvatar('systems')}><Cpu size={15} />Systems</button>
            <button className={`avatar-option${avatar === 'teal' ? ' is-selected' : ''}`} type="button" aria-pressed={avatar === 'teal'} onClick={() => setAvatar('teal')}><Check size={15} />Teal</button>
          </div>}
        </div>
        <div className="profile-fields-column">
          <div className="profile-identity-grid">
            <div className="form-field"><label className="field-label" htmlFor="profile-full-name">Full name</label><input className="text-input" id="profile-full-name" value={fullName} readOnly /></div>
            <div className="form-field"><label className="field-label" htmlFor="profile-role">Assigned role</label><input className="text-input" id="profile-role" value={roleLabels[role]} readOnly /></div>
            <div className="form-field"><label className="field-label" htmlFor="profile-email">Email address</label><input className="text-input" id="profile-email" value={emailAddress || 'Not provided'} readOnly /></div>
            <div className="form-field"><label className="field-label" htmlFor="profile-display-name">Display name</label><input className="text-input" id="profile-display-name" value={name} onChange={(event) => { setName(event.target.value); setSaved(false); setError('') }} maxLength={40} autoComplete="nickname" required aria-invalid={Boolean(error)} aria-describedby={error ? 'profile-name-error' : undefined} /></div>
          </div>
          {error && <p className="form-error" id="profile-name-error" role="alert">{error}</p>}
          <div className="profile-save-row"><button className="button button-primary" type="submit">Save Changes <Check size={16} /></button>{saved && <p className="profile-save-status" role="status">Profile updated for this session.</p>}</div>
        </div>
      </section>
    </form>
  </div>
}

function PeopleTable<T extends { name: string; email: string; status: string }>({ people, mode, onSelect }: { people: T[]; mode: 'student' | 'instructor'; onSelect?: (person: T) => void }) {
  return <div className="people-table"><div className="people-table-head"><span>NAME</span><span>EMAIL</span><span>{mode === 'student' ? 'CLASS / PROGRESS' : 'CLASSES'}</span><span>STATUS</span><span /></div>{people.map((person) => {
    const student = person as T & { className?: string; progress?: number; classes?: number }
    return <div className="people-row" key={person.email}><span className="person-name-cell"><span className="avatar avatar-table">{person.name.split(' ').map((part) => part[0]).slice(0, 2).join('')}</span><strong>{person.name}</strong></span><span className="person-email">{person.email}</span><span className="person-detail">{mode === 'student' ? <>{student.className}<small>{student.progress ?? 0}% activity</small></> : `${student.classes ?? 0} class${student.classes === 1 ? '' : 'es'}`}</span><span><em className={`status-badge ${person.status === 'Active' ? 'status-active' : 'status-neutral'}`}>{person.status}</em></span><button className="table-action" type="button" onClick={() => onSelect?.(person)} aria-label={`View ${person.name}`}>View <ArrowRight size={14} /></button></div>
  })}{people.length === 0 && <p className="empty-search">No records match that search.</p>}</div>
}

function PersonModal<T extends { name: string; email: string; status: string }>({ person, onClose }: { person: T; onClose: () => void }) {
  const row = person as T & { className?: string; progress?: number; classes?: number }
  return <Modal title={person.name} description="Account details" onClose={onClose}><div className="modal-summary"><p><Mail size={15} /> {person.email}</p><div className="modal-stat-line"><span>Account status</span><strong>{person.status}</strong></div>{row.className && <div className="modal-stat-line"><span>Class</span><strong>{row.className}</strong></div>}{typeof row.progress === 'number' && <div className="modal-stat-line"><span>Activity</span><strong>{row.progress}%</strong></div>}{typeof row.classes === 'number' && <div className="modal-stat-line"><span>Classes</span><strong>{row.classes}</strong></div>}</div><button className="button button-primary button-full" onClick={onClose} type="button">Close</button></Modal>
}

function InviteModal({ role, complete, onSubmit, onClose }: { role: 'student' | 'instructor'; complete: boolean; onSubmit: () => void; onClose: () => void }) {
  const submit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); onSubmit() }
  const roleLabel = role === 'student' ? 'CSS Student' : 'CSS Instructor'
  const article = role === 'student' ? 'a' : 'an'
  return <Modal title={complete ? 'Invitation details reviewed' : `Invite ${article} ${role}`} description={complete ? 'This action has not been sent.' : `Prepare ${roleLabel} invitation details.`} onClose={onClose}>
    {complete ? <div className="invite-success" role="status"><span><Check size={18} /></span><strong>Details reviewed</strong><p>No email was sent. Invitation delivery is not connected.</p><button className="button button-primary button-full" type="button" onClick={onClose}>Done</button></div> : <DemoForm className="modal-form" onSubmit={submit}><label className="field-label" htmlFor="invitee-email">Invitee email</label><input className="text-input" type="email" id="invitee-email" placeholder="name@school.edu" required /><label className="field-label" htmlFor="invitee-role">Assigned role</label><input className="text-input" id="invitee-role" value={roleLabel} readOnly /><label className="field-label" htmlFor="invitee-class">Class</label><select className="text-input" id="invitee-class"><option>CSS 11 · Section A</option><option>CSS 11 · Section B</option></select><p className="privacy-note">Invitation delivery is unavailable.</p><div className="modal-actions"><button className="button button-quiet" type="button" onClick={onClose}>Cancel</button><button className="button button-primary" type="submit">Review details <ArrowRight size={15} /></button></div></DemoForm>}
  </Modal>
}
