import { ArrowLeft, Mail, Send } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Link } from 'react-router'
import { AuthLayout } from '../components/AuthLayout'
import { Brand } from '../components/Brand'

export function ForgotPasswordPage() {
  const [submitted, setSubmitted] = useState(false)
  const submit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); setSubmitted(true) }
  return <AuthLayout compact><div className="auth-card recovery-card">
    <div className="auth-brand-lockup"><Brand compact /><p>Movers Institute of Technology and Education</p></div>
    <div className="auth-card-heading"><h2>Forgot your password?</h2><p>Password recovery is not connected. No email will be sent.</p></div>
    {submitted ? <div className="inline-notice" role="status">Recovery is unavailable here. No message was sent.</div> : <form className="auth-form" onSubmit={submit}><label className="field-label" htmlFor="recovery-email">Account email</label><div className="input-wrap"><Mail size={16} /><input id="recovery-email" type="email" required placeholder="name@school.edu" /></div><button className="button button-primary button-full" type="submit">Check recovery availability <Send size={15} /></button></form>}
    <div className="auth-card-footer"><Link to="/login"><ArrowLeft size={13} /> Return to login</Link><span>Invitation-only access</span></div>
  </div></AuthLayout>
}
