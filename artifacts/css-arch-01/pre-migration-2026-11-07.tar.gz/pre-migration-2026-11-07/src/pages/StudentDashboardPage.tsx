import { ArrowRight, BookOpen, Clock3, Cpu, HardDrive, Layers3, PackageOpen, Play, Sparkles, Wrench } from 'lucide-react'
import type { ReactNode } from 'react'
import { Link } from 'react-router'
import { usePrototypeState } from '../app/use-prototype-state'
import { PageHeading, SectionHeading } from '../components/PageHeading'

const activities = [
  { title: 'Hardware exploration', path: '/student/hardware', description: 'Learn what each component does and how it fits into a computer system.', cta: 'Explore components', icon: Cpu, index: '01', tone: 'activity-hardware', meta: 'COMPONENT LIBRARY' },
  { title: 'Guided assembly', path: '/student/assembly', description: 'Follow a clear sequence as the system comes together, part by part.', cta: 'Start assembly', icon: Wrench, index: '02', tone: 'activity-assembly', meta: 'STEP BY STEP' },
  { title: 'Guided disassembly', path: '/student/disassembly', description: 'Practice removing components safely from an assembled system.', cta: 'Start disassembly', icon: PackageOpen, index: '03', tone: 'activity-disassembly', meta: 'REVERSE THE BUILD' },
]

const assignedActivities = [
  { title: 'System assembly sequence', detail: 'Procedural assessment · 8 steps', due: 'Assigned by instructor', progress: 0 },
  { title: 'Component identification', detail: 'Hardware knowledge · 6 items', due: 'Not started', progress: 0 },
]

export function StudentDashboardPage() {
  const { displayName } = usePrototypeState()
  const firstName = displayName.split(' ')[0]
  return <div className="dashboard-page student-page">
    <PageHeading eyebrow="STUDENT WORKSPACE" title={`Good morning, ${firstName}.`} description="Choose a learning activity and build your understanding at your own pace." action={<Link className="button button-secondary button-small" to="/student/progress">View my progress <ArrowRight size={15} /></Link>} />
    <section className="activities-section" aria-labelledby="activity-title">
      <SectionHeading title="Your learning activities" detail="Guided practice you can revisit whenever you need." action={<span className="section-kicker"><Sparkles size={14} /> START HERE</span>} />
      <div className="activity-grid">
        {activities.map(({ title, path, description, cta, icon: Icon, index, tone, meta }) => <article className={`activity-card ${tone}`} key={title}>
          <div className="activity-card-top"><span className="activity-icon"><Icon size={19} strokeWidth={1.75} /></span><span className="activity-index">{index}</span></div>
          <div className="activity-visual" aria-hidden="true"><div className="visual-line visual-line-one" /><div className="visual-line visual-line-two" /><div className="visual-device"><Icon size={30} strokeWidth={1.3} /></div><span className="visual-node node-a" /><span className="visual-node node-b" /></div>
          <p className="card-meta">{meta}</p><h3>{title}</h3><p className="activity-description">{description}</p>
          <Link className="activity-link" to={path}>{cta}<ArrowRight size={15} /></Link>
        </article>)}
      </div>
    </section>

    <div className="student-secondary-grid">
      <section className="content-panel assignments-panel">
        <SectionHeading title="Assigned assessments" detail="Separate from independent practice." action={<Link className="subtle-link" to="/student/assessments">View all <ArrowRight size={14} /></Link>} />
        <div className="assignment-list">{assignedActivities.map((assignment, index) => <Link className="assignment-row" to="/student/assessments" key={assignment.title}>
          <span className="assignment-number">0{index + 1}</span><span className="assignment-copy"><strong>{assignment.title}</strong><small>{assignment.detail}</small></span><span className="assignment-status">{assignment.due}</span><ArrowRight size={15} className="assignment-arrow" />
        </Link>)}</div>
      </section>
      <section className="content-panel progress-panel">
        <SectionHeading title="My progress" detail="A quick look at your practice." action={<Link className="subtle-link" to="/student/progress">Details <ArrowRight size={14} /></Link>} />
        <div className="progress-visual"><div className="progress-ring"><span>0%</span></div><div><strong>Your learning journey starts here</strong><span>Progress tracking is not available yet.</span></div></div>
        <div className="progress-mini-row"><span><Clock3 size={14} /> Practice is self-paced</span><span><BookOpen size={14} /> Repeat any guided activity</span></div>
      </section>
    </div>
    <section className="recent-activity-strip"><span className="recent-icon"><HardDrive size={17} /></span><span><strong>Recent activity</strong><small>No activity yet. Start with hardware exploration.</small></span><Link to="/student/hardware" aria-label="Go to hardware exploration"><Play size={14} fill="currentColor" /></Link><Layers3 className="recent-watermark" size={70} aria-hidden="true" />
    </section>
  </div>
}

export function StudentActivityPreview({ title, type }: { title: string; type: 'hardware' | 'assembly' | 'disassembly' }) {
  const info = {
    hardware: { icon: Cpu, eyebrow: 'COMPONENT LIBRARY', copy: 'Explore the purpose, function, and place of common computer hardware. 3D viewing and rotate/zoom controls are planned for a later phase.' },
    assembly: { icon: Wrench, eyebrow: 'GUIDED INSTALLATION', copy: 'A future walkthrough will guide you through the assembly sequence, with parts presented in an organized area.' },
    disassembly: { icon: PackageOpen, eyebrow: 'GUIDED REMOVAL', copy: 'A future walkthrough will begin with an assembled computer and guide component removal in sequence.' },
  }[type]
  const Icon = info.icon
  return <div className="activity-preview-page">
    <div className="preview-heading"><p className="eyebrow">LEARNING ACTIVITY</p></div>
    <div className="activity-preview-hero"><div className="preview-illustration"><Icon size={62} strokeWidth={1.1} /><span className="preview-orbit orbit-one" /><span className="preview-orbit orbit-two" /><i className="preview-dot" /></div><div className="activity-preview-copy"><span className="card-meta">{info.eyebrow}</span><h1>{title}</h1><p>{info.copy}</p><div className="preview-note"><span className="note-marker" /> Interactive 3D content and activity tracking are not available yet.</div><Link to="/student/dashboard" className="button button-primary">Back to student dashboard <ArrowRight size={16} /></Link></div></div>
  </div>
}

export function StudentAssessmentsPage() {
  return <div className="dashboard-page"><PageHeading eyebrow="STUDENT WORKSPACE" title="Assigned assessments" description="Instructor-assigned procedural activities appear here, separate from independent practice." />
    <section className="content-panel table-panel"><SectionHeading title="Your assignments" detail="Activities assigned by your CSS Instructor." /><div className="assignment-detail-row"><div className="table-icon"><Wrench size={18} /></div><div className="assignment-detail-copy"><strong>System assembly sequence</strong><span>Procedural assessment · 8 steps · Assigned by CSS Instructor</span></div><span className="status-badge status-assigned">Ready</span><Link to="/student/assembly" className="button button-secondary button-small">Open activity <ArrowRight size={14} /></Link></div><div className="assignment-detail-row"><div className="table-icon"><Cpu size={18} /></div><div className="assignment-detail-copy"><strong>Component identification</strong><span>Hardware knowledge · 6 items · Assigned by CSS Instructor</span></div><span className="status-badge status-neutral">Not started</span><Link to="/student/hardware" className="button button-secondary button-small">Open activity <ArrowRight size={14} /></Link></div></section>
  </div>
}

export function StudentProgressPage() {
  return <div className="dashboard-page"><PageHeading eyebrow="STUDENT WORKSPACE" title="My progress" description="Progress is based on completed learning activities and assigned procedural assessments." />
    <div className="metric-grid"><Metric label="Activities explored" value="0 / 3" icon={<Cpu size={18} />} note="This visit" /><Metric label="Guided practice" value="0 sessions" icon={<Wrench size={18} />} note="Independent practice" /><Metric label="Assessments" value="0 / 2" icon={<BookOpen size={18} />} note="Instructor assigned" /></div>
    <section className="content-panel progress-detail-panel"><SectionHeading title="Learning overview" detail="Your completed activities will appear here." /><div className="empty-progress"><div className="empty-progress-mark"><Layers3 size={24} /></div><strong>Your practice story starts with one activity.</strong><span>Try component exploration or a guided assembly or disassembly activity.</span><Link to="/student/hardware" className="button button-primary button-small">Explore hardware <ArrowRight size={14} /></Link></div></section>
  </div>
}

function Metric({ label, value, icon, note }: { label: string; value: string; icon: ReactNode; note: string }) {
  return <article className="metric-card"><span className="metric-icon">{icon}</span><span className="metric-note">{note}</span><strong>{value}</strong><span className="metric-label">{label}</span></article>
}
