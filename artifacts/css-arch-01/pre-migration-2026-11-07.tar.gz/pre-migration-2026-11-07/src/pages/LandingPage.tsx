import { ArrowRight, Cpu, GraduationCap, Layers3, LogIn, Menu, Wrench, X } from 'lucide-react'
import { useEffect, useState } from 'react'
import { Link } from 'react-router'
import { Brand } from '../components/Brand'

const features = [
  {
    title: 'Hardware Exploration',
    icon: Cpu,
    points: [
      'Explore selected computer hardware components.',
      'Review component names, descriptions, and functions.',
      'Rotation and zoom for interactive 3D models are planned, but are not available yet.',
    ],
  },
  {
    title: 'Guided Assembly',
    icon: Layers3,
    points: [
      'Follow step-by-step computer assembly procedures.',
      'Understand component placement and installation sequence.',
      'Guided virtual hardware assembly is planned for a future implementation.',
    ],
  },
  {
    title: 'Guided Disassembly',
    icon: Wrench,
    points: [
      'Follow step-by-step component removal procedures.',
      'Understand the sequence for disassembling computer hardware.',
      'Guided virtual hardware removal is planned for a future implementation.',
    ],
  },
]

export function LandingPage() {
  const [activeSection, setActiveSection] = useState(() => window.location.hash || '#home')
  const [mobileNavOpen, setMobileNavOpen] = useState(false)

  useEffect(() => {
    const syncActiveSection = () => setActiveSection(window.location.hash || '#home')
    window.addEventListener('hashchange', syncActiveSection)
    return () => window.removeEventListener('hashchange', syncActiveSection)
  }, [])

  return <main className="landing-page" id="home">
    <div className="cinematic-photo" aria-hidden="true" />
    <header className="landing-header">
      <div className="landing-identity"><Brand compact /></div>
      <nav className={`landing-nav${mobileNavOpen ? ' is-open' : ''}`} id="landing-navigation" aria-label="Main navigation">
        <a className={activeSection === '#home' ? 'is-current' : undefined} aria-current={activeSection === '#home' ? 'location' : undefined} href="#home" onClick={() => { setActiveSection('#home'); setMobileNavOpen(false) }}>Home</a>
        <a className={activeSection === '#about' ? 'is-current' : undefined} aria-current={activeSection === '#about' ? 'location' : undefined} href="#about" onClick={() => { setActiveSection('#about'); setMobileNavOpen(false) }}>About</a>
        <a className={activeSection === '#features' ? 'is-current' : undefined} aria-current={activeSection === '#features' ? 'location' : undefined} href="#features" onClick={() => { setActiveSection('#features'); setMobileNavOpen(false) }}>Features</a>
      </nav>
      <div className="landing-controls">
        <button className="landing-mobile-toggle" type="button" aria-label={mobileNavOpen ? 'Close site navigation' : 'Open site navigation'} aria-expanded={mobileNavOpen} aria-controls="landing-navigation" onClick={() => setMobileNavOpen((open) => !open)}>
          {mobileNavOpen ? <X size={19} aria-hidden="true" /> : <Menu size={19} aria-hidden="true" />}
        </button>
        <Link className="button button-primary landing-login-link" to="/login"><LogIn size={15} /> Login / Sign Up</Link>
      </div>
    </header>

    <section className="landing-hero" aria-labelledby="landing-title">
      <p className="landing-institution">Movers Institute of Technology and Education</p>
      <p className="landing-eyebrow"><span /> COMPUTER SYSTEMS SERVICING</p>
      <h1 id="landing-title">VR-Based Computer Systems Servicing (CSS) Training Application</h1>
      <p className="landing-description">An interactive learning tool for exploring computer hardware and becoming familiar with basic assembly and disassembly procedures through guided virtual activities.</p>
      <div className="landing-actions">
        <Link className="button button-primary landing-start" to="/login"><LogIn size={16} /> Get Started <ArrowRight size={16} /></Link>
        <a className="button button-outline-light" href="#about"><GraduationCap size={16} /> Learn More</a>
      </div>
    </section>

    <section className="landing-about" id="about" aria-labelledby="about-title">
      <div className="landing-section-heading">
        <p className="landing-section-eyebrow">ABOUT THE PROJECT</p>
        <h2 id="about-title">About the CSS Training Application</h2>
      </div>
      <div className="landing-about-copy">
        <p>The VR-Based Computer Systems Servicing (CSS) Training Application is an interactive learning tool developed for Movers Institute of Technology and Education. It is designed to help students explore computer hardware components, understand their functions, and become familiar with basic computer assembly and disassembly procedures through guided virtual activities.</p>
        <p className="landing-support-note">This application supplements classroom instruction and physical hands-on training.</p>
      </div>
    </section>

    <section className="landing-feature-section" id="features" aria-labelledby="features-title">
      <div className="landing-feature-heading">
        <div className="landing-section-heading">
          <p className="landing-section-eyebrow">LEARNING ACTIVITIES</p>
          <h2 id="features-title">Explore the Learning Experience</h2>
        </div>
        <p className="landing-planned-note">These describe the intended learning experience. Interactive 3D activities are planned for a later phase.</p>
      </div>
      <div className="landing-feature-grid">
        {features.map(({ title, points, icon: Icon }) => <article className="landing-feature-card" key={title}>
          <div className="landing-feature-card-heading"><Icon size={23} strokeWidth={1.7} aria-hidden="true" /><h3>{title}</h3></div>
          <ul>{points.map((point) => <li key={point}>{point}</li>)}</ul>
        </article>)}
      </div>
    </section>

    <footer className="landing-footer"><span>SUPPLEMENTARY LEARNING TOOL</span><span>Supports classroom instruction and physical hands-on training</span></footer>
  </main>
}
