import { Eye, EyeOff, GraduationCap, LockKeyhole, Mail, ShieldCheck, UserRound } from 'lucide-react'
import { useState, type FormEvent } from 'react'
import { Link, useLocation, useNavigate } from 'react-router'
import { type DemoRole } from '../app/prototype-config'
import { usePrototypeState } from '../app/use-prototype-state'
import { AuthLayout } from '../components/AuthLayout'
import { Brand } from '../components/Brand'

const roleOptions: { role: DemoRole; short: string }[] = [
  { role: 'student', short: 'Student' },
  { role: 'instructor', short: 'Instructor' },
  { role: 'principal', short: 'Principal' },
]

export function LoginPage() {
  const [role, setRole] = useState<DemoRole>('student')
  const [emailAddress, setEmailAddress] = useState('')
  const [showPassword, setShowPassword] = useState(false)
  const navigate = useNavigate()
  const location = useLocation()
  const { chooseRole } = usePrototypeState()
  const activated = Boolean((location.state as { activationComplete?: boolean } | null)?.activationComplete)

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    chooseRole(role, emailAddress)
    navigate('/profile-setup', { state: { role } })
  }

  return <AuthLayout>
    <div className="auth-card login-card centered-auth-card">
      <div className="auth-brand-lockup">
        <Brand compact />
        <p>Movers Institute of Technology and Education</p>
      </div>
      <div className="auth-card-heading">
        <h1>Welcome Back</h1>
        <p>Access your CSS training workspace.</p>
      </div>
      <div className="auth-tabs" role="tablist" aria-label="Account access">
        <button className="is-selected" type="button" role="tab" aria-selected="true">Login</button>
        <Link to="/activate-account" role="tab" aria-selected="false">Sign Up</Link>
      </div>
      {activated && <div className="inline-notice" role="status">Account creation is not connected. Continue to role-based workspace entry.</div>}
      <form className="auth-form centered-login-form" onSubmit={submit}>
        <label className="field-label" htmlFor="login-email">Email Address</label>
        <div className="input-wrap"><Mail size={17} aria-hidden="true" /><input id="login-email" name="email" type="email" autoComplete="email" placeholder="Enter your email" value={emailAddress} onChange={(event) => setEmailAddress(event.target.value)} /></div>
        <div className="field-row-label"><label className="field-label" htmlFor="login-password">Password</label><Link to="/forgot-password">Forgot Password?</Link></div>
        <div className="input-wrap"><LockKeyhole size={17} aria-hidden="true" /><input id="login-password" name="password" type={showPassword ? 'text' : 'password'} autoComplete="current-password" placeholder="Enter your password" /><button className="password-toggle" type="button" onClick={() => setShowPassword((show) => !show)} aria-label={showPassword ? 'Hide password' : 'Show password'}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div>
        <button className="button button-primary button-full centered-login-button" type="submit">Continue</button>
      </form>
      <div className="auth-divider"><span />or continue as<span /></div>
      <fieldset className="role-fieldset role-fieldset-centered">
        <legend>Choose a workspace</legend>
        <div className="role-choice-group" role="radiogroup" aria-label="Choose a workspace">
          {roleOptions.map(({ role: option, short }) => {
            const Icon = option === 'student' ? GraduationCap : option === 'instructor' ? UserRound : ShieldCheck
            return <label key={option} className={`role-choice role-choice-card${role === option ? ' is-selected' : ''}`}>
              <input type="radio" name="workspace-role" value={option} checked={role === option} onChange={() => setRole(option)} />
              <Icon size={20} aria-hidden="true" />
              <span>{short}</span>
            </label>
          })}
        </div>
      </fieldset>
      <p className="login-access-note">Sign-in is not connected. Choosing a role opens that workspace.</p>
    </div>
  </AuthLayout>
}
