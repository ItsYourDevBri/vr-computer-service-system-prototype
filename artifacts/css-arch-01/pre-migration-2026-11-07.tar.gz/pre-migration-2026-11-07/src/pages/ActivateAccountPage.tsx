import { ArrowLeft, BadgeCheck, CalendarDays, CircleAlert, Mail, Phone, UserRound } from 'lucide-react'
import { useState, type FormEvent, type ReactNode } from 'react'
import { Link, useNavigate } from 'react-router'
import { AuthLayout } from '../components/AuthLayout'
import { Brand } from '../components/Brand'

type InvitationState = 'valid' | 'invalid' | 'expired' | 'complete'

function initialInvitationState(): InvitationState {
  if (!import.meta.env.DEV) return 'valid'
  const fixture = new URLSearchParams(window.location.search).get('invitationFixture')
  return fixture === 'invalid' || fixture === 'expired' ? fixture : 'valid'
}

export function ActivateAccountPage() {
  const [invitationState, setInvitationState] = useState<InvitationState>(initialInvitationState)
  const [fullName, setFullName] = useState('')
  const [age, setAge] = useState('')
  const [contact, setContact] = useState('')
  const [password, setPassword] = useState('')
  const [confirmPassword, setConfirmPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    if (password !== confirmPassword) {
      setError('Passwords do not match. Check both fields and try again.')
      return
    }
    setError('')
    setPassword('')
    setConfirmPassword('')
    setFullName('')
    setAge('')
    setContact('')
    setInvitationState('complete')
  }

  return <AuthLayout compact>
    <div className="auth-card activation-card">
      <header className="activation-header">
        <Link className="activation-back-link" to="/login"><ArrowLeft size={17} /> Back to Login</Link>
        <Brand compact />
      </header>
      <div className="auth-card-heading activation-heading">
        <h2>Activate your account</h2>
        <p>Complete your details to access your CSS training workspace.</p>
      </div>
      {invitationState === 'valid' && <>
        <form className="auth-form activation-form" onSubmit={submit}>
          <div className="form-grid form-grid-two">
            <div className="form-field span-two"><label className="field-label" htmlFor="invite-email">Invited email</label><div className="input-wrap input-readonly"><Mail size={16} /><input id="invite-email" value="student@movers.test" readOnly aria-readonly="true" /></div></div>
            <div className="form-field"><label className="field-label" htmlFor="invite-role">Assigned role</label><input className="text-input" id="invite-role" value="CSS Student" readOnly aria-readonly="true" /></div>
            <div className="form-field"><label className="field-label" htmlFor="invite-age">Age</label><div className="input-wrap"><CalendarDays size={16} /><input id="invite-age" type="number" min="12" max="99" value={age} onChange={(event) => setAge(event.target.value)} placeholder="Optional" /></div></div>
            <div className="form-field span-two"><label className="field-label" htmlFor="invite-name">Full name</label><div className="input-wrap"><UserRound size={16} /><input id="invite-name" value={fullName} onChange={(event) => setFullName(event.target.value)} autoComplete="name" placeholder="Your full name" required /></div></div>
            <div className="form-field span-two"><label className="field-label" htmlFor="invite-contact">Contact number <span className="label-hint">Optional</span></label><div className="input-wrap"><Phone size={16} /><input id="invite-contact" type="tel" autoComplete="tel" value={contact} onChange={(event) => setContact(event.target.value)} placeholder="09XX XXX XXXX" /></div></div>
            <div className="form-field"><label className="field-label" htmlFor="invite-password">Create password</label><input className="text-input" id="invite-password" type="password" autoComplete="new-password" minLength={8} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="8+ characters" required /></div>
            <div className="form-field"><label className="field-label" htmlFor="invite-confirm">Confirm password</label><input className="text-input" id="invite-confirm" type="password" autoComplete="new-password" minLength={8} value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} placeholder="Repeat password" required /></div>
          </div>
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="button button-primary button-full" type="submit">Activate account <BadgeCheck size={17} /></button>
        </form>
      </>}
      {invitationState === 'invalid' && <InvitationMessage icon={<CircleAlert size={21} />} title="Invitation not recognized" text="We couldn't verify these invitation details. Ask your CSS Instructor for a current invitation." action={<button className="button button-secondary button-full" onClick={() => setInvitationState('valid')} type="button">Return to the form</button>} />}
      {invitationState === 'expired' && <InvitationMessage icon={<CalendarDays size={21} />} title="Invitation expired" text="This invitation is outside its activation window. Ask the inviter for a current invitation." action={<button className="button button-secondary button-full" onClick={() => setInvitationState('valid')} type="button">Return to the form</button>} />}
      {invitationState === 'complete' && <InvitationMessage icon={<BadgeCheck size={22} />} title="Details checked" text="Account creation isn't connected, so no account was created." action={<button className="button button-primary button-full" onClick={() => navigate('/login', { state: { activationComplete: true } })} type="button">Continue to login</button>} success />}
    </div>
  </AuthLayout>
}

function InvitationMessage({ icon, title, text, action, success = false }: { icon: ReactNode; title: string; text: string; action: ReactNode; success?: boolean }) {
  return <div className={`invitation-message${success ? ' invitation-message-success' : ''}`} role={success ? 'status' : 'alert'}><span className="invitation-message-icon">{icon}</span><h3>{title}</h3><p>{text}</p>{action}</div>
}
