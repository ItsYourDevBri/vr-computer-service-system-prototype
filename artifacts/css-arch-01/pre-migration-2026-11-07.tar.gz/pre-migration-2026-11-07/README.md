# CSS VR Training Application

A mobile-first local UI/UX prototype for the research project **A VR-Based Computer Systems Servicing (CSS) Training Application with Interactive Hardware Learning for Movers Institute of Technology and Education**. CSS-UI-01 provides simulated invitation/profile flows and Student, Instructor, and Principal dashboards. CSS-UI-01A adds the cinematic landing page and centered login/sign-up experience.

The application is a supplementary educational tool for physical hands-on instruction. The landing page identifies the planned learning activities and marks unfinished 3D interactions as future work. Read [project context](docs/project-context.md) and [system flow](docs/system-flow.md) for the approved scope.

## Technology

- React, TypeScript, and Vite
- Tailwind CSS v4 with `@tailwindcss/vite`
- React Router in declarative mode
- Lucide React
- Playwright Test
- npm

Resolved package versions are in `package.json` and `package-lock.json`. Vite's current Node requirement is Node 20.19+ or 22.12+; this workspace was detected with Node 24.11.1 and npm 11.6.2.

## Requirements

- Node.js 20.19+ (or 22.12+)
- npm
- Chromium browser binaries for Playwright end-to-end tests

## Setup

```sh
npm install
npx playwright install chromium
```

## Local development

```sh
npm run dev
```

Vite prints the local URL, normally `http://localhost:5173/`.

## Checks

```sh
npm run typecheck
npm run lint
npm run build
npm run test:e2e
```

The Playwright suite checks landing/login/dashboard navigation, invitation and role flows, and horizontal overflow at 320, 375, 390, 430, 768, 1024, and 1440 pixel widths, plus phone landscape layouts. It captures review images in `artifacts/css-ui-01/`. Authentication, invitations, sample records, class actions, and assessment assignment are simulated; they are not production functionality. The lab photograph source and license are recorded in [asset credits](docs/asset-credits.md).

## Project structure

- `src/` — app shell, route map, and global styles
- `public/images/` — the user-supplied MITE seal and classroom photo
- `docs/` — approved project context, system flows, and architecture
- `tests/` — browser smoke checks
- `blender_assets/` — existing Blender hardware project assets, kept separate from app source

CSS-UI-01A provides the cinematic landing and centered authentication screens; CSS-UI-01B integrates the supplied school seal and adds About and Features sections. The prototype does not include 3D interactions, GLB integration, or VR rendering.
